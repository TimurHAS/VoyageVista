<?php
// ============================================================
//  VoyageVista — includes/api_panier.php
//  Sauvegarde / lecture du panier en base de données.
//  Actions : save | load | clear | confirm
// ============================================================

ini_set('display_errors', 0);
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/db.php';

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    http_response_code(401);
    exit(json_encode(['ok' => false, 'error' => 'Non connecté.']));
}

// Crée la table carts si elle n'existe pas (sans FK pour éviter les erreurs de contrainte)
$db = getDB();
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS carts (
            id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id        INT UNSIGNED NOT NULL UNIQUE,
            destination_id INT UNSIGNED DEFAULT NULL,
            transport_id   INT UNSIGNED DEFAULT NULL,
            hotel_id       INT UNSIGNED DEFAULT NULL,
            activity_ids   TEXT         DEFAULT NULL,
            adults         TINYINT UNSIGNED NOT NULL DEFAULT 2,
            children       TINYINT UNSIGNED NOT NULL DEFAULT 0,
            nights         TINYINT UNSIGNED NOT NULL DEFAULT 7,
            bags           VARCHAR(20)  DEFAULT '0',
            ticket         VARCHAR(20)  DEFAULT 'Basic',
            seat           VARCHAR(20)  DEFAULT 'Standard',
            room_type      VARCHAR(20)  DEFAULT 'standard',
            hotel_options  TEXT         DEFAULT NULL,
            checkin        DATE         DEFAULT NULL,
            checkout       DATE         DEFAULT NULL,
            status         ENUM('open','confirmed','cancelled') NOT NULL DEFAULT 'open',
            updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");
} catch (Exception $e) {
    exit(json_encode(['ok' => false, 'error' => 'Erreur création table: ' . $e->getMessage()]));
}

// Crée la table bookings si elle n'existe pas
$db->exec("
    CREATE TABLE IF NOT EXISTS bookings (
        id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id        INT UNSIGNED NOT NULL,
        destination_id INT UNSIGNED DEFAULT NULL,
        transport_id   INT UNSIGNED DEFAULT NULL,
        hotel_id       INT UNSIGNED DEFAULT NULL,
        activity_ids   TEXT         DEFAULT NULL,
        adults         TINYINT UNSIGNED NOT NULL DEFAULT 2,
        children       TINYINT UNSIGNED NOT NULL DEFAULT 0,
        nights         TINYINT UNSIGNED NOT NULL DEFAULT 7,
        checkin        DATE         DEFAULT NULL,
        checkout       DATE         DEFAULT NULL,
        room_type      VARCHAR(20)  DEFAULT 'standard',
        total_price    DECIMAL(10,2) DEFAULT NULL,
        status         ENUM('confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
        created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_hotel (hotel_id, checkin, checkout),
        INDEX idx_user  (user_id)
    ) ENGINE=InnoDB
");

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? ($_GET['action'] ?? 'load');

// Valide une date au format YYYY-MM-DD et retourne null si invalide
function validateDate(?string $date): ?string {
    if (empty($date)) return null;
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return ($d && $d->format('Y-m-d') === $date) ? $date : null;
}

try { switch ($action) {

    // ── Sauvegarder le panier ──────────────────────────────────
    case 'save':
        $activityIds  = isset($body['activity_ids']) ? implode(',', array_map('intval', (array)$body['activity_ids'])) : '';
        $hotelOptions = isset($body['hotel_options']) ? json_encode((array)$body['hotel_options']) : '[]';

        $checkin  = validateDate($body['checkin']  ?? null);
        $checkout = validateDate($body['checkout'] ?? null);

        // Validation : checkin doit être avant checkout et dans le futur
        if ($checkin && $checkout) {
            $today = new DateTime('today');
            $ci    = new DateTime($checkin);
            $co    = new DateTime($checkout);
            if ($ci >= $co) {
                http_response_code(400);
                exit(json_encode(['ok' => false, 'error' => 'La date d\'arrivée doit être avant la date de départ.']));
            }
            if ($ci < $today) {
                http_response_code(400);
                exit(json_encode(['ok' => false, 'error' => 'La date d\'arrivée ne peut pas être dans le passé.']));
            }
        }

        $stmt = $db->prepare("
            INSERT INTO carts
                (user_id, destination_id, transport_id, hotel_id, activity_ids,
                 adults, children, nights, bags, ticket, seat, room_type,
                 hotel_options, checkin, checkout)
            VALUES
                (:u, :dest, :tr, :ht, :acts,
                 :ad, :ch, :ni, :bags, :ticket, :seat, :room,
                 :hopt, :ci, :co)
            ON DUPLICATE KEY UPDATE
                destination_id = VALUES(destination_id),
                transport_id   = VALUES(transport_id),
                hotel_id       = VALUES(hotel_id),
                activity_ids   = VALUES(activity_ids),
                adults         = VALUES(adults),
                children       = VALUES(children),
                nights         = VALUES(nights),
                bags           = VALUES(bags),
                ticket         = VALUES(ticket),
                seat           = VALUES(seat),
                room_type      = VALUES(room_type),
                hotel_options  = VALUES(hotel_options),
                checkin        = VALUES(checkin),
                checkout       = VALUES(checkout),
                status         = 'open'
        ");
        $stmt->execute([
            ':u'     => $userId,
            ':dest'  => $body['destination_id'] ? (int)$body['destination_id'] : null,
            ':tr'    => $body['transport_id']   ? (int)$body['transport_id']   : null,
            ':ht'    => $body['hotel_id']       ? (int)$body['hotel_id']       : null,
            ':acts'  => $activityIds,
            ':ad'    => max(1, (int)($body['adults']   ?? 2)),
            ':ch'    => max(0, (int)($body['children'] ?? 0)),
            ':ni'    => max(1, (int)($body['nights']   ?? 7)),
            ':bags'  => $body['bags']       ?? '0',
            ':ticket'=> $body['ticket']     ?? 'Basic',
            ':seat'  => $body['seat']       ?? 'Standard',
            ':room'  => $body['room_type']  ?? 'standard',
            ':hopt'  => $hotelOptions,
            ':ci'    => $checkin,
            ':co'    => $checkout,
        ]);
        exit(json_encode(['ok' => true]));

    // ── Charger le panier ──────────────────────────────────────
    case 'load':
        $stmt = $db->prepare('SELECT * FROM carts WHERE user_id = :u AND status = "open" LIMIT 1');
        $stmt->execute([':u' => $userId]);
        $cart = $stmt->fetch();
        if (!$cart) {
            exit(json_encode(['ok' => true, 'cart' => null]));
        }
        // Recompose les ids activités en tableau
        $cart['activity_ids']  = $cart['activity_ids'] ? array_map('intval', explode(',', $cart['activity_ids'])) : [];
        $cart['hotel_options'] = json_decode($cart['hotel_options'] ?? '[]', true);
        exit(json_encode(['ok' => true, 'cart' => $cart]));

    // ── Vider le panier ────────────────────────────────────────
    case 'clear':
        $stmt = $db->prepare('DELETE FROM carts WHERE user_id = :u');
        $stmt->execute([':u' => $userId]);
        exit(json_encode(['ok' => true]));

    // ── Confirmer la commande ──────────────────────────────────
    case 'confirm':
        // Charge le panier courant
        $stmtCart = $db->prepare('SELECT * FROM carts WHERE user_id = :u AND status = "open" LIMIT 1');
        $stmtCart->execute([':u' => $userId]);
        $cart = $stmtCart->fetch();

        if (!$cart) {
            http_response_code(400);
            exit(json_encode(['ok' => false, 'error' => 'Aucun panier ouvert à confirmer.']));
        }

        // Vérification disponibilité hôtel (anti-double réservation)
        if ($cart['hotel_id'] && $cart['checkin'] && $cart['checkout']) {
            $avail = $db->prepare(
                'SELECT COUNT(*) FROM bookings
                 WHERE hotel_id = :hid
                   AND status = "confirmed"
                   AND checkin  < :co
                   AND checkout > :ci'
            );
            $avail->execute([
                ':hid' => $cart['hotel_id'],
                ':co'  => $cart['checkout'],
                ':ci'  => $cart['checkin'],
            ]);
            if ((int)$avail->fetchColumn() > 0) {
                http_response_code(409);
                exit(json_encode(['ok' => false, 'error' => 'Cet hôtel n\'est plus disponible pour ces dates. Veuillez choisir d\'autres dates ou un autre hébergement.']));
            }
        }

        // Vérification capacité activités (max 20 participants par activité par jour)
        if (!empty($cart['activity_ids'])) {
            $actIds = array_filter(array_map('intval', explode(',', $cart['activity_ids'])));
            $participants = (int)$cart['adults'] + (int)$cart['children'];
            foreach ($actIds as $actId) {
                $capCheck = $db->prepare(
                    'SELECT COALESCE(SUM(adults + children), 0) FROM bookings
                     WHERE status = "confirmed"
                       AND FIND_IN_SET(:aid, activity_ids)
                       AND checkin = :ci'
                );
                $capCheck->execute([':aid' => $actId, ':ci' => $cart['checkin']]);
                $already = (int)$capCheck->fetchColumn();
                if ($already + $participants > 20) {
                    http_response_code(409);
                    exit(json_encode(['ok' => false, 'error' => 'Une activité sélectionnée n\'a plus de places disponibles pour cette date. Veuillez modifier votre sélection.']));
                }
            }
        }

        // Persiste la réservation dans bookings
        $db->beginTransaction();
        try {
            $insBook = $db->prepare(
                'INSERT INTO bookings
                    (user_id, destination_id, transport_id, hotel_id, activity_ids,
                     adults, children, nights, checkin, checkout, room_type, status)
                 VALUES
                    (:u, :dest, :tr, :ht, :acts,
                     :ad, :ch, :ni, :ci, :co, :room, "confirmed")'
            );
            $insBook->execute([
                ':u'    => $userId,
                ':dest' => $cart['destination_id'],
                ':tr'   => $cart['transport_id'],
                ':ht'   => $cart['hotel_id'],
                ':acts' => $cart['activity_ids'],
                ':ad'   => $cart['adults'],
                ':ch'   => $cart['children'],
                ':ni'   => $cart['nights'],
                ':ci'   => $cart['checkin'],
                ':co'   => $cart['checkout'],
                ':room' => $cart['room_type'],
            ]);

            $db->prepare('UPDATE carts SET status = "confirmed" WHERE user_id = :u AND status = "open"')
               ->execute([':u' => $userId]);

            $db->prepare(
                'INSERT INTO notifications (user_id, category, title, message, icon, color)
                 VALUES (:u, "Réservations", "Réservation confirmée", "Votre réservation a été enregistrée avec succès.", "check", "teal")'
            )->execute([':u' => $userId]);

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
        exit(json_encode(['ok' => true]));

    default:
        http_response_code(400);
        exit(json_encode(['ok' => false, 'error' => 'Action inconnue.']));

} } catch (Exception $e) {
    http_response_code(500);
    exit(json_encode(['ok' => false, 'error' => 'Erreur serveur: ' . $e->getMessage()]));
}
